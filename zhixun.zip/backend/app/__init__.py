"""Agentic Simulation Platform - 销冠培养系统 & 社恐培养系统"""

__version__ = "0.1.0"
