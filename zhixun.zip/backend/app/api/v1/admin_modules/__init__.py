"""
开发：Excellent（11964948@qq.com）
功能：管理后台API模块
作用：导出管理后台相关路由
创建时间：2025-12-24
最后修改：2025-12-24
"""

from app.api.v1.admin_modules import dashboard

__all__ = ["dashboard"]
