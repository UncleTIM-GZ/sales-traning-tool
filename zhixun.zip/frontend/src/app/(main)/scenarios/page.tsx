import { redirect } from "next/navigation";

export default function ScenariosPage() {
  redirect("/plaza");
}
