// 根路由使用 (public) 路由组的首页
export { default } from "./(public)/page";
